Thank you for downloading from Tempees.com

Enjoy your design element for free. 
We hope they will serve and facilitate your work.

But if you think, buy us a beer :)

WWW.TEMPEES.COM
free design stuff
---------------------------

DONATE: http://www.tempees.com/donate

TWITTER: @tempeescom

FACEBOOK: https://www.facebook.com/tempeescom

---------------------------

LICENCE:
All of our site is free, and you can use it where you want. For private and commercial purposes.